// Auto-generated. Do not edit.
declare namespace LCD1IN8 {
}


    /*****************************************************************************
     * | File        :   LCD1in8_Driver.h
     * | Author      :   Waveshare team
     * | Function    :   ILI9486 Drive function
     * | Info        :
     *   Image scanning
     *      Please use progressive scanning to generate images or fonts
     *----------------
     * | This version:   V1.0
     * | Date        :   2018-01-11
     * | Info        :   Basic version
     *
     ******************************************************************************/

    declare const enum LCD_COLOR {
    WHITE = 0xFFFF,
    BLACK = 0x0000,
    BLUE = 0x001F,
    BRED = 0XF81F,
    GRED = 0XFFE0,
    GBLUE = 0X07FF,
    RED = 0xF800,
    MAGENTA = 0xF81F,
    GREEN = 0x07E0,
    CYAN = 0x7FFF,
    YELLOW = 0xFFE0,
    BROWN = 0XBC40,
    BRRED = 0XFC07,
    GRAY = 0X8430,
    }


    declare const enum DOT_PIXEL {
    DOT_PIXEL_1 = 1,
    DOT_PIXEL_2 = 2,
    DOT_PIXEL_3 = 3,
    DOT_PIXEL_4 = 4,
    }


    declare const enum LINE_STYLE {
    LINE_SOLID = 0,
    LINE_DOTTED = 1,
    }


    declare const enum DRAW_FILL {
    DRAW_EMPTY = 0,
    DRAW_FULL = 1,
    }

// Auto-generated. Do not edit. Really.
