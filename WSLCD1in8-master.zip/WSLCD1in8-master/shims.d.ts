// Auto-generated. Do not edit.


    /*****************************************************************************
     * | File      	:   LCD1in8.cpp
     * | Author      :   Waveshare team
     * | Function    :   Contorl lcd Show
     * | Info        :
     *----------------
     * | This version:   V1.0
     * | Date        :   2018-05-02
     * | Info        :   Basic version
     *
     ******************************************************************************/
    //% weight=20 color=#436EEE icon="\uf108"
declare namespace LCD1IN8 {
}

// Auto-generated. Do not edit. Really.
